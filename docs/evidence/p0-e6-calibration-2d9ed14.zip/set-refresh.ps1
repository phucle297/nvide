param(
    [Parameter(Mandatory = $true)]
    [ValidateSet(60, 120)]
    [int]$RefreshHz
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class Phase0Display {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct DEVMODE {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion;
        public short dmDriverVersion;
        public short dmSize;
        public short dmDriverExtra;
        public int dmFields;
        public int dmPositionX;
        public int dmPositionY;
        public int dmDisplayOrientation;
        public int dmDisplayFixedOutput;
        public short dmColor;
        public short dmDuplex;
        public short dmYResolution;
        public short dmTTOption;
        public short dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel;
        public int dmPelsWidth;
        public int dmPelsHeight;
        public int dmDisplayFlags;
        public int dmDisplayFrequency;
        public int dmICMMethod;
        public int dmICMIntent;
        public int dmMediaType;
        public int dmDitherType;
        public int dmReserved1;
        public int dmReserved2;
        public int dmPanningWidth;
        public int dmPanningHeight;
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern bool EnumDisplaySettingsW(string deviceName, int modeNumber, ref DEVMODE mode);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int ChangeDisplaySettingsExW(string deviceName, ref DEVMODE mode, IntPtr window, uint flags, IntPtr parameter);
}
"@

$mode = New-Object Phase0Display+DEVMODE
$modeSize = [Runtime.InteropServices.Marshal]::SizeOf($mode)
$mode.dmSize = $modeSize
$deviceName = "\\.\DISPLAY1"
if (![Phase0Display]::EnumDisplaySettingsW($deviceName, -1, [ref]$mode)) {
    throw "EnumDisplaySettingsW failed for DEVMODE size $modeSize"
}
$mode.dmFields = 0x00400000
$mode.dmDisplayFrequency = $RefreshHz
if ([Phase0Display]::ChangeDisplaySettingsExW($deviceName, [ref]$mode, [IntPtr]::Zero, 0x00000002, [IntPtr]::Zero) -ne 0) {
    throw "$RefreshHz Hz mode failed validation"
}
if ([Phase0Display]::ChangeDisplaySettingsExW($deviceName, [ref]$mode, [IntPtr]::Zero, 0, [IntPtr]::Zero) -ne 0) {
    throw "failed to switch to $RefreshHz Hz"
}
Start-Sleep -Seconds 2
$current = Get-CimInstance Win32_VideoController | Select-Object -First 1
if ($current.CurrentRefreshRate -ne $RefreshHz) {
    throw "requested $RefreshHz Hz but Windows reports $($current.CurrentRefreshRate) Hz"
}
[pscustomobject]@{
    Width = $current.CurrentHorizontalResolution
    Height = $current.CurrentVerticalResolution
    RefreshHz = $current.CurrentRefreshRate
} | ConvertTo-Json -Compress
